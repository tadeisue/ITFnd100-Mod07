# ------------------------------------------------- #
# Title: Assignment_07_
# Description: Learning to work with Structured Error Handling
# ChangeLog: (Who, When, What)
# Susan Tadei Dev,05/29/2023,Created Script
# ------------------------------------------------- #

try:
    quotient = 5/0
    print(quotient)
except Exception as e:
    print("There was an error! << Custom Message")

    print("Built-In Pythons error info: ")
    print(e)
    print(type(e))
    print(e.__doc__)
    print(e.__str__())


